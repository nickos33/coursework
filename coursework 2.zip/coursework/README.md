### Install
```
mvn clean install
```

### Launch the server
```
mvn exec:java@server
```

### Launch the client
```
mvn exec:java@client
```
